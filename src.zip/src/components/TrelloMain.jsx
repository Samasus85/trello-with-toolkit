import React from 'react'
import Flex from '../UI/Flex'
import TodoTrello from './TodoTrello'
import CardTasks from './CardTasks'

const TrelloMain = () => {
  return (
    <div>
      <Flex>
        <TodoTrello />
        <CardTasks />
      </Flex>
    </div>
  )
}

export default TrelloMain